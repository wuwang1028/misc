ls
cat .bash_history 
vim .bash_history 
echo "" >  .bash_history 
vim .bash_history 
ls
cat .bash_history 
ls
cat .bash_history 
ls l
ls la
ls -la
vim .bash_history 
ls
cat .bash_history 
ls
ls -la
ifconfig
cd /usr/local/
ls
cd tomcat/
ls
cd webapps/
ls
cd ROOT/
ls
cd ../..
ls
cd ..
cd apache-tomcat-8.5.93/
ls
cd ..
ls
cd tomcat
ls
cd webapps/
cd ROOT/
LS
ls
cd springboot3/
ls
cd ..
ls
cd springboot3/
ls
java -jar test-0.0.1-SNAPSHOT.jar 
ls
rm -rf test-0.0.1-SNAPSHOT.jar 
rm -rf log/
'//tmp/VMwareDnD/JebddH/test-0.0.1-SNAPSHOT.jar' 
ls
ll ~
mv ~/桌面/test-0.0.1-SNAPSHOT.jar ./
ls
chmod +x test-0.0.1-SNAPSHOT.jar 
java -jar test-0.0.1-SNAPSHOT.jar 
cd log/
ls
rm -rf spring.log 
cd ..
ls
java -jar test-0.0.1-SNAPSHOT.jar 
cd /usr/vulhub-master/
ls
cd struts2/
cd s2-061/
ls
docker compose up -d
cat .bash_history 
cd /home/
ls
cd hyp/
ls
ls -l
ls -a
cat .bash_history
cd ..
cd ~
cat .bash_history 
cat .bash_history 
cd /usr/local/tomcat/
ls
cd bin
sh startup.sh
cd ../webapps/ROOT/
ls
cd springboot3/
ls
cd log/
ls
cat spring.log 
cd /usr
ls
cd /usr/local/tomcat/webapps/ROOT/
ls
cd springboot3/
cd log/
ls
cp spring.log spring.log.bak 
ls
cd ..
ls
java -jar test-0.0.1-SNAPSHOT.jar 
ls
cd log/
ls -la
cd ../webapps/ROOT/
ls
cd springboot3/
ls
zip test-0.0.1-SNAPSHOT.jar code.jar
zip code.zip test-0.0.1-SNAPSHOT.jar
ls
mysqldump -u root -p --all-databases > back.sql
ls
cd~
cd ~
ls
cd Desktop/
ls
rm -rf 1.png flag.jpg test.jsp 
ls
passwd root
ssh-keygen -t rsa
cat /root/.ssh/id_rsa
whoami
cd ~
cat .bash_history 
ls
